import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    title: "KEL 3",
    home: kel3(),
  ));
}

class kel3 extends StatefulWidget {
  @override
  _kel3State createState() => _kel3State();
}

class _kel3State extends State<kel3> {
  List<String> agama = [
    "islam",
    "kristen protestan",
    "kristen katolik",
    "hindu",
    "budha",
  ];

  String _agama = "islam";

  String _jk = "";

  TextEditingController controllerNama = new TextEditingController();
  TextEditingController controllerPass = new TextEditingController();
  TextEditingController controllerMoto = new TextEditingController();

  void _pilihJk(String value) {
    setState(() {
      _jk = value;
    });
  }

  void pilihAgama(String value) {
    setState(() {
      _agama = value;
    });
  }

  void kirimdata() {
    AlertDialog alertDialog = new AlertDialog(
      content: new Container(
        height: 200,
        child: new Column(
          children: [
            new Text("Nama Lengkap : ${controllerNama.text}"),
            new Text("Password : ${controllerPass.text}"),
            new Text("Moto hidup : ${controllerMoto.text}"),
            new Text("Jenis kelamin : ${_jk}"),
            new Text("Agama : ${_agama}"),
            new RaisedButton(
                child: new Text("OK"),
                onPressed: () => Navigator.pop(context),
                color: Colors.teal
            )
          ],
        ),
      ),
    );
    showDialog(context: context, builder: (_) => alertDialog);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("data diri"),
        backgroundColor: Colors.teal,
      ),
      body: new Container(
        padding: new EdgeInsets.all(10),
        child: new Column(
          children: [
            new TextField(
              controller: controllerNama,
              decoration: new InputDecoration(
                  hintText: "Nama lengkap",
                  labelText: "Nama lengkap",
                  border: new OutlineInputBorder(
                      borderRadius: new BorderRadius.circular(20))),
            ),
            new Padding(
              padding: new EdgeInsets.only(top: 20),
            ),
            new TextField(
              controller: controllerPass,
              obscureText: true,
              decoration: new InputDecoration(
                  hintText: "Password",
                  labelText: "Password",
                  border: new OutlineInputBorder(
                      borderRadius: new BorderRadius.circular(20))),
            ),
            new Padding(
              padding: new EdgeInsets.only(top: 20),
            ),
            new TextField(
              controller: controllerMoto,
              maxLines: 3,
              decoration: new InputDecoration(
                  hintText: "Moto Hidup",
                  labelText: "Moto hidup",
                  border: new OutlineInputBorder(
                      borderRadius: new BorderRadius.circular(20))),
            ),
            new Padding(
              padding: new EdgeInsets.only(top: 20),
            ),
            new RadioListTile(
              value: "laki laki",
              title: new Text("Laki-laki"),
              groupValue: _jk,
              onChanged: (String? value) {
                _pilihJk(value!);
              },
              activeColor: Colors.blue,
              subtitle: new Text("Pilih ini jika anda laki laki"),
            ),
            new RadioListTile(
              value: "perempuan",
              title: new Text("perempuan"),
              groupValue: _jk,
              onChanged: (String? value) {
                _pilihJk(value!);
              },
              activeColor: Colors.blue,
              subtitle: new Text("Pilih ini jika anda perempuan"),
            ),
            new Padding(
              padding: new EdgeInsets.only(top: 20),
            ),
            new Row(
              children: [
                new Text(
                  "Agama",
                  style: new TextStyle(fontSize: 18, color: Colors.blue),
                ),
                new Padding(
                  padding: new EdgeInsets.only(left: 15),
                ),
                DropdownButton(
                  onChanged: (String? value) {
                    pilihAgama(value!);
                  },
                  value: _agama,
                  items: agama.map((String value) {
                    return new DropdownMenuItem(
                      value: value,
                      child: new Text(value),
                    );
                  }).toList(),
                )
              ],
            ),
            new RaisedButton(
                child: new Text("OK"),
                color: Colors.teal,
                onPressed: () {
                  kirimdata();
                })
          ],
        ),
      ),
    );
  }
}