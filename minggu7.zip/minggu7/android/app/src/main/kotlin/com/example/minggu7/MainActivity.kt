package com.example.minggu7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
