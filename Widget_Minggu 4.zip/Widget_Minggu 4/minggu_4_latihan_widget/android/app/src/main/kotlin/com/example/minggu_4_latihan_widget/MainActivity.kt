package com.example.minggu_4_latihan_widget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
