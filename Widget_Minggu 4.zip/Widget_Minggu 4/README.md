E41201570 Andi Wicaksono NUgroho

1. Sketsa
![1  sketsa](https://user-images.githubusercontent.com/75154388/158769313-25751fc6-db42-4694-9b44-edcc9a91b2f7.jpeg)

2. Wireframe
![2  wireframe](https://user-images.githubusercontent.com/75154388/158769323-5da7c5bc-9d8b-4fe3-a519-df3142703bac.png)

3. Widget
![3  widget](https://user-images.githubusercontent.com/75154388/158769326-b5afdb43-23d8-4e22-b43f-b9f9267eaca7.png)

4. Tele
![4  tele](https://user-images.githubusercontent.com/75154388/158769330-c0cb2adb-df7c-4b36-b031-c5790ce3646d.png)

![5  tele](https://user-images.githubusercontent.com/75154388/158769332-a05975f5-d32a-4fb4-988e-1ed4a2b2b477.png)

